function KondeskRequestADemo() {
  
  let firstname = jQuery("#kondesk-register-ads-form").find("#firstname").val();
  let lastname = jQuery("#kondesk-register-ads-form").find("#lastname").val();
  let email = jQuery("#kondesk-register-ads-form").find("#email").val();
  let mobile = jQuery("#kondesk-register-ads-form").find("#mobile").val();
  // let companyname = jQuery("#kondesk-register-ads-form").find("#company").val();
  // let web = jQuery("#kondesk-register-ads-form").find("#web").val();
  let job = jQuery("#kondesk-register-ads-form").find("#job").val();
  let address = jQuery("#kondesk-register-ads-form").find("#address").val();
  let message = jQuery("#kondesk-register-ads-form").find("#message").val();
  let city = jQuery("#kondesk-register-ads-form").find("#city").val();
  let state = jQuery("#kondesk-register-ads-form").find("#state").val();
  let country = jQuery("#kondesk-register-ads-form").find("#country").val();
  let dateofbirth = jQuery("#kondesk-register-ads-form").find("#dateofbirth").val();
  let nationality = jQuery("#kondesk-register-ads-form").find("#nationality").val();
  let gender = jQuery("#kondesk-register-ads-form").find("#gender").val();
  let maritalstatus = jQuery("#kondesk-register-ads-form").find("#maritalstatus").val();
  let inquirytype = jQuery("#kondesk-register-ads-form").find("#inquirytype").val();
  let zipcode = jQuery("#kondesk-register-ads-form").find("#zipcode").val();
  
  // Get the access key token from the input field
  let accessKeyToken = jQuery("#access_key_token").val();

  // Perform the validation
  
    // Check if the form is valid
    if (jQuery("#kondesk-register-ads-form").valid()) {
      
      jQuery.ajax({
        type: "POST",
        url: wpkdl.ajax_url,
        data: {
          action: "wpkdl_get_leads",
          firstname: firstname,
          lastname: lastname,
          email: email,
          mobile: mobile,
          // companyname: companyname,   
          // web: web,
          job: job,
          address: address,
          message: message,
          city: city,
          state: state,
          country: country,
          dateofbirth: dateofbirth,
          nationality: nationality,
          gender: gender,
          maritalstatus: maritalstatus,
          inquirytype: inquirytype,
          zipcode: zipcode,
        },
        dataType: "json", // Make sure the response is in JSON format
        beforeSend: function(xhr) {
            xhr.setRequestHeader('Access-Key-Token', accessKeyToken);
        },
        success: function(response) {
          // Check if the response was successful
          if (response['flag'] === true) {
              var message = response['message'];
              // Handle successful response              
              jQuery("#kondesk-register-ads-form").html(message);
          } else {
              $message = response['message'];
              jQuery("#OutputMsg").html("Error to Save Lead!");
          }      
        },
        complete: function () {
          // Re-enable the submit button
          jQuery("#kondesk-submit").prop("disabled", true);
          jQuery("#kondesk-register-ads-form")[0].reset();
          jQuery("#OutputMsg").show();
          jQuery("#OutputMsg").html("Lead Saved Successfully!");
        },
      });
    }
 
}

jQuery(document).ready(function () {
  jQuery("#OutputMsg").hide();
  // jQuery("#kondesk-register-ads-form").on("click", "#kondesk-submit", function () {
  //     KondeskRequestADemo();
  // });
});



// jQuery.validator.addMethod("web", function(element) {
//   return this.optional(element);
// }, "Please enter enter a valid website.");

// jQuery.validator.addMethod("phone", function(value, element) {
//   return this.optional(element) || /^\+?\d{0,3}?\d{0,12}$/.test(value);
// }, "Please enter a valid phone number.");

// jQuery.validator.addMethod("companyname", function(value, element) {
//   return this.optional(element) || /^[A-Za-z0-9\s]{1,50}$/.test(value);
// }, "Please enter a valid company name.");

// jQuery.validator.addMethod("job", function(value, element) {
//   return this.optional(element) || value.length >= 2;
// }, "Please enter a valid job title (minimum 2 characters).");

// jQuery.validator.addMethod("message", function(value, element) {
//   return value.length <= 255;
// }, "Comments cannot exceed 255 characters.");

jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-zA-Z\s]+$/.test(value);
}, "Please enter letters only.");


jQuery(document).ready(function($) {
  $("#kondesk-register-ads-form").validate({
    errorPlacement: function(error, element) {
      error.insertAfter(element);
    },
    rules: {
      firstname: {
        required: true,
        maxlength: 15,
        lettersonly: true
      },
      lastname: {        
        maxlength: 15,
        lettersonly: true
      },
      email: {
        required: true,
        email: true
      },
      mobile: {
        required: true,
        mobile: true,
        digits: true,
        maxlength: 12,
        minlength: 8
      },
      // company: {
      //   lettersonly: true
      // },
      // web: {       
      //   web: true
      // },
      job: {        
        lettersonly: true
      },
      address: {       
        lettersonly: true
      },
      message: {
        maxlength: 255
      },
      zipcode: {
        digits: true,
        maxlength: 8,
        minlength: 5
      },
      dateofbirth: {
        dateofbirth: true,
        maxlength: 12,
        minlength: 8
      },
      nationality: {       
        lettersonly: true
      },
      gender: {        
        lettersonly: true
      },
      maritalstatus: {       
        lettersonly: true
      },
      inquirytype: {
        lettersonly: true,
        maxlength: 255
      }
    },
    messages: {
      firstname: {
        required: "Please enter your first name.",
        maxlength: "First name cannot exceed 15 characters.",
        lettersonly: "Please enter only letters."
      },
      lastname: {       
        maxlength: "Last name cannot exceed 15 characters.",
        lettersonly: "Please enter only letters."
      },
      email: {
        required: "Please enter your email address.",
        email: "Please enter a valid email address."
      },
      mobile: {
        required: "Please enter your phone number.",
        digits: "Please enter only digits.",
        maxlength: "Phone number cannot exceed 12 digits.",
        minlength: "Phone number should have at least 8 digits."
      },
      // company: {        
      //   lettersonly: "Please enter only letters."
      // },
      // web: {
      //   required: "Please enter a website starting with http:// or https://."
      // },
      job: {       
        lettersonly: "Please enter only letters."
      },
      address: {        
        lettersonly: "Please enter only letters."
      },
      message: {
        maxlength: "Comments cannot exceed 255 characters."
      },
      zipcode: {
        required: "Please enter your zip code.",
        digits: "Please enter only digits for the zip code.",
        minlength: "Zip code should have 5 digits.",
        maxlength: "Zip code should have 8 digits."
      },
      inquirytype: {        
        lettersonly: "Please enter only letters."
      },
      maritalstatus: {
        lettersonly: "Please enter only letters."
      },
      gender: {       
        lettersonly: "Please enter only letters."
      },
      nationality: {        
        lettersonly: "Please enter only letters."
      },
      dateofbirth: {
        required: "Please enter your date of birth.",
        maxlength: "Date of birth cannot exceed 12 digits.",
        minlength: "Date of birth should have at least 8 digits."
      }
    }
  });

  // Conditionally add or remove web field validation
  // var webField = $("#web");
  // if (webField.attr("required")) {
  //   $.validator.addMethod(
  //     "web",
  //     function(value, element) {
  //       return /^(https?:\/\/)/.test(value);
  //     },
  //     "Please enter a valid website starting with http:// or https://."
  //   );
  //   webField.rules("add", {
  //     web: true
  //   });
  // } else {
  //   webField.rules("remove", "web");
  // }

  // Conditionally add or remove phone field validation
  var mobileField = $("#mobile");
  if (mobileField.attr("required")) {
    $.validator.addMethod(
      "mobile",
      function(value, element) {
        return this.optional(element) || /^\+?\d{0,3}?\d{0,12}$/.test(value);
      },
      "Please enter a valid mobile number."
    );
    mobileField.rules("add", {
      mobile: true
    });
  } else {
    mobileField.rules("remove", "mobile");
  }

  // Conditionally add or remove zipcode field validation
  var zipcodeField = $("#zipcode");
  if (zipcodeField.attr("required")) {
    $.validator.addMethod(
      "zipcode",
      function(value, element) {
        return this.optional(element) || /^\+?\d{0,3}?\d{0,12}$/.test(value);
      },
      "Please enter a valid zipcode."
    );
    zipcodeField.rules("add", {
      zipcode: true
    });
  } else {
    zipcodeField.rules("remove", "zipcode");
  }

  // Conditionally add or remove dateofbirth field validation
  var dateField = $("#dateofbirth");
  if (dateField.attr("required")) {
    $.validator.addMethod(
      "dateofbirth",
      function(value, element) {
        // Match the format "dd-mm-yyyy"
        return this.optional(element) || /^\d{2}-\d{2}-\d{4}$/.test(value);
      },
      "Please enter a valid date of birth in the format dd-mm-yyyy."
    );
    dateField.rules("add", {
      dateofbirth: true
    });
  } else {
    dateField.rules("remove", "dateofbirth");
  }

  
});


function addBootstrapToForm() {
  // Check if the form exists on the page
  var form = document.getElementById('kondesk-register-ads-form'); // Replace 'your-form-id' with the actual ID of your form

  if (form) {
      // Create a link element for Bootstrap CSS
      var bootstrapCSS = document.createElement('link');
      bootstrapCSS.rel = 'stylesheet';
      bootstrapCSS.href = 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css';

      // Create a Script element for Lead JS
      var LeadJS = document.createElement('script');
      LeadJS.src = location.origin + '/wp-content/plugins/kondesk-leads/js/leads.js';

      // Append the Bootstrap CSS link to the head section
      form.appendChild(bootstrapCSS);
      form.appendChild(LeadJS);

      // Remove the Bootstrap CSS from other sections
      var allSections = document.querySelectorAll('header:not(#kondesk-register-ads-form)');
      allSections.forEach(function(otherSection) {
          var bootstrapCSSLink = otherSection.querySelector('link[href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"]');
          if (bootstrapCSSLink) {
              bootstrapCSSLink.remove();
          }
      });
  }
}

// Execute the function when the DOM is ready
document.addEventListener('DOMContentLoaded', addBootstrapToForm);