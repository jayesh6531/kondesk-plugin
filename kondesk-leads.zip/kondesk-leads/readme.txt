=== Kondesk Leads ===
Contributors: konze
Tags: Contacts List, table, database, data, WP_List_Table, Crud
Author link: https://kondesk.com/
Donate link: https://subscription.kondesk.com/?key=rZd4ddOMtNDd31nM5N2IXQ==
Requires at least: 4.9
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
-------------------------------------------------------------------------------------------------------------------------
- The plugin creates custom Kondesk Lead list tables using the WP_List_Table class, allowing you to perform CRUD operations (Create, Read, Update, Delete) on leads.

- The plugin includes a form on the front end where users can make inquiries and fill out the form. The submitted information is then stored as leads in the Kondesk CRM system, providing an organized way to manage and track leads generated through the form.

- With this plugin, you can efficiently handle lead management within your WordPress plugin development workflow, streamlining the process of capturing and managing user inquiries.

== The main features of this plugin for managing leads in a WordPress plugin development context could include: ==
------------------------------------------------------------------------------------------------------------------------
1. Lead List Tables: The plugin creates custom lead list tables using the WP_List_Table class, allowing you to view and                           manage leads in an organized and user-friendly interface.

2. CRUD Operations:  The plugin enables you to perform essential CRUD operations (Create, Read, Update, Delete) on leads.                         This means you can add new leads, view existing leads, update lead information, and delete unwanted                          leads.

3. Front-End Form:   The plugin includes a user-friendly form on the front end where visitors or users can make inquiries and submit their information. This form serves as a means for capturing leads and integrating them into the lead management system.

4. Lead Tracking:    The plugin tracks and stores the submitted form data as leads in the Kondesk CRM system. This feature allows you to keep a record of all inquiries and easily manage and track leads generated through the form.

5. Integration with Kondesk CRM:  The plugin seamlessly integrates with the Kondesk CRM system, ensuring that leads captured through the front-end form are efficiently managed within the CRM environment.

6. Streamlined Lead Management:   By utilizing this plugin, you can streamline your lead management process, making it easier to organize, track, and follow up on leads generated through the form. This can help improve overall efficiency and effectiveness in managing and nurturing potential customers.

For more information, please refer to the WP_List_Tables page in the WordPress Codex.

== Installation ==
-----------------------------------------------------------------------------------------------------------------------
1. Upload the plugin folder to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. The plugin adds a menu item under 'Kondesk' in the admin area.
4. Click on 'Kondesk' in the admin menu to access the lead list.

== Frequently Asked Questions ==
-----------------------------------------------------------------------------------------------------------------------
**Is there any configuration required for this plugin?**
- No, the plugin works out of the box without any additional configuration.

**Are all features of this plugin completely free?**
- Yes, all features provided by this plugin are free to use.

== Upgrade Notice ==
-----------------------------------------------------------------------------------------------------------------------
= 1.1 =
- Added new features.
- Improved performance and stability.

== Changelog ==
-----------------------------------------------------------------------------------------------------------------------
= 1.0 =
- Initial release.

== Donate ==
-----------------------------------------------------------------------------------------------------------------------
If you find this plugin useful and would like to support its development, you can make a donation [here](https://subscription.kondesk.com/?key=rZd4ddOMtNDd31nM5N2IXQ==).

== Screenshots ==
-----------------------------------------------------------------------------------------------------------------------
1. ![Kondesk Lead List Table](screenshots/screenshot-1.png)
2. ![Add new Lead](screenshots/screenshot-2.png)
3. ![Edit Lead](screenshots/screenshot-3.png)
4. ![Configure Lead Settings](screenshots/screenshot-4.png)
