<?php

/**
 * Plugin Name: KONDESK Leads 
 * Description: For KONDESK user, to add all inquiry in KONDESK. KONEDSK credentails are required.
 * Version:     0.0.1
 * Plugin URI:  https://konze.com/products/kondesk/
 * Author:      KONZE 
 * Author URI:  https://konze.com
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wpkdl
 * Domain Path: /languages
 */

defined('ABSPATH') or die('¡Wrong Turn!');

require plugin_dir_path(__FILE__) . 'includes/kdleads-form.php';
require plugin_dir_path(__FILE__) . 'includes/kdleads-settings.php';

function wpkdl_custom_admin_styles($hook)
{
    if ( $hook === 'kondesk_page_kdleads_settings' || $hook === 'kondesk_page_kdleads_form' || $hook === 'toplevel_page_kdleads' ) {
        // Enqueue Bootstrap CSS
        wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css');
        
        // Enqueue custom styles
        wp_enqueue_style('custom-styles', plugins_url('/css/styles.css', __FILE__));
    }
}
add_action('admin_enqueue_scripts', 'wpkdl_custom_admin_styles');



function wpkdl_plugin_load_textdomain()
{
    load_plugin_textdomain('wpkdl', false, basename(dirname(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'wpkdl_plugin_load_textdomain');

function enqueue_bootstrap_assets()
{
    if (is_page() && has_shortcode(get_post_field('post_content', get_queried_object_id()), 'kondesk_lead')) {
        wp_enqueue_style('plugin-style', plugin_dir_url(__FILE__) . '/css/styles.css');
    }
}
add_action('wp_enqueue_scripts', 'enqueue_bootstrap_assets');

global $wpkdl_db_version;
$wpkdl_db_version = '0.0.1';


function wpkdl_install()
{
    global $wpdb;
    global $wpkdl_db_version;

    $table_name = $wpdb->prefix . 'kd_leads';


    $sql = "CREATE TABLE " . $table_name . " (
        id int(11) NOT NULL AUTO_INCREMENT,
        firstname VARCHAR (50) NOT NULL,
        lastname VARCHAR (100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        mobile VARCHAR(15) NULL,
        job VARCHAR(100) NULL,
        address VARCHAR (250) NULL,
        message VARCHAR (250) NULL,
        city VARCHAR (250) NULL,
        state VARCHAR (250) NULL,
        country VARCHAR (250) NULL,
        dateofbirth VARCHAR(15) NULL,
        nationality VARCHAR(15) NULL,
        gender VARCHAR(15) NULL,
        maritalstatus VARCHAR(15) NULL,
        inquirytype VARCHAR(15) NULL,
        zipcode VARCHAR(15) NULL,
      PRIMARY KEY  (id)
    );";


    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    add_option('wpkdl_db_version', $wpkdl_db_version);

    // company VARCHAR(100) NULL,
    // web VARCHAR(100) NULL,  

    $installed_ver = get_option('wpkdl_db_version');
    if ($installed_ver != $wpkdl_db_version) {
        $sql = "CREATE TABLE " . $table_name . " (
          id int(11) NOT NULL AUTO_INCREMENT,
          firstname VARCHAR (50) NOT NULL,
          lastname VARCHAR (100) NOT NULL,
          email VARCHAR(100) NOT NULL,
          mobile VARCHAR(15) NULL,          
          job VARCHAR(100) NULL,          
          address VARCHAR (250) NULL,
          message VARCHAR (250) NULL,
          city VARCHAR (250) NULL,
          state VARCHAR (250) NULL,
          country VARCHAR (250) NULL,
          dateofbirth VARCHAR(15) NULL,
          nationality VARCHAR(15) NULL,
          gender VARCHAR(15) NULL,
          maritalstatus VARCHAR(15) NULL,
          inquirytype VARCHAR(15) NULL,
          zipcode VARCHAR(15) NULL,
          PRIMARY KEY  (id)
    );";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        update_option('wpkdl_db_version', $wpkdl_db_version);
    }
}

register_activation_hook(__FILE__, 'wpkdl_install');


function wpkdl_install_data()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'kd_leads';
}

register_activation_hook(__FILE__, 'wpkdl_install_data');


function wpkdl_update_db_check()
{
    global $wpkdl_db_version;
    if (get_site_option('wpkdl_db_version') != $wpkdl_db_version) {
        wpkdl_install();
    }
}

add_action('plugins_loaded', 'wpkdl_update_db_check');



if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}


class Custom_Table_Example_List_Table extends WP_List_Table
{
    function __construct()
    {
        global $status, $page;

        parent::__construct(array(
            'singular' => 'kdlead',
            'plural'   => 'kdleads',
        ));
    }

    function column_default($item, $column_name)
    {
        return $item[$column_name];
    }

    function column_phone($item)
    {
        return '<em>' . $item['mobile'] . '</em>';
    }

    function column_name($item)
    {

        $actions = array(
            'edit' => sprintf('<a href="?page=kdleads_form&id=%s">%s</a>', $item['id'], __('Edit', 'wpkdl')),
            'delete' => sprintf('<a href="?page=%s&action=delete&id=%s">%s</a>', $_REQUEST['page'], $item['id'], __('Delete', 'wpkdl')),
        );

        return sprintf(
            '%s %s',
            $item['name'],
            $this->row_actions($actions)
        );
    }

    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="id[]" value="%s" />',
            $item['id']
        );
    }

    //Lead List Columns Array
    function get_columns()
    {
        $columns = array(
            'cb' => '<input type="checkbox" />',
            'firstname'      => __('Name', 'wpkdl'),
            'lastname'  => __('LName', 'wpkdl'),
            'email'     => __('E-Mail', 'wpkdl'),
            'mobile'     => __('Mobile', 'wpkdl'),
            // 'company'   => __('Company', 'wpkdl'),
            // 'web'       => __('Web', 'wpkdl'),
            'job'       => __('Job Title', 'wpkdl'),
            'address'       => __('Address', 'wpkdl'),
            'message'       => __('Message', 'wpkdl'),
            'city'       => __('City', 'wpkdl'),
            'state'       => __('State', 'wpkdl'),
            'country'       => __('Country', 'wpkdl'),
            'dateofbirth'       => __('Dob', 'wpkdl'),
            'nationality'       => __('Nationlity', 'wpkdl'),
            'gender'       => __('Gender', 'wpkdl'),
            'maritalstatus'       => __('Status', 'wpkdl'),
            'inquirytype'       => __('Inquiry', 'wpkdl'),
            'zipcode'       => __('Zipcode', 'wpkdl'),
        );
        return $columns;
    }

    // Lead List Columns Sorting
    function get_sortable_columns()
    {
        $sortable_columns = array(
            'firstname'      => array('firstname', true),
            'lastname'  => array('lastname', true),
            'email'     => array('email', true),
            'mobile'     => array('mobile', true),
            // 'company'   => array('company', true),
            // 'web'       => array('web', true),
            'job'       => array('job', true),
            'address'   => array('address', true),
            'message'   => array('message', true),
            'city'      => array('city', true),
            'state'     => array('state', true),
            'country'   => array('country', true),
            'dateofbirth'   => array('dateofbirth', true),
            'nationality'   => array('nationality', true),
            'gender'        => array('gender', true),
            'maritalstatus' => array('maritalstatus', true),
            'inquirytype'   => array('inquirytype', true),
            'zipcode'       => array('zipcode', true),
        );
        return $sortable_columns;
    }

    function get_bulk_actions()
    {
        $actions = array(
            'delete' => 'Delete'
        );
        return $actions;
    }

    function process_bulk_action()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'kd_leads';

        if ('delete' === $this->current_action()) {
            $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();
            if (is_array($ids)) $ids = implode(',', $ids);

            if (!empty($ids)) {
                $wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
            }
        }
    }

    //Lead List Pagination and table
    function prepare_items()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'kd_leads';

        $per_page = 20;

        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = array($columns, $hidden, $sortable);

        $this->process_bulk_action();

        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");

        $paged = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) - 1) : 0;
        $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'lastname';
        $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';

        // Get the latest page ID from the database
        $latest_page_id = $wpdb->get_var("SELECT MAX(id) FROM $table_name");

        // Increment the latest page ID by one to get the next page ID
        $page_id = $latest_page_id + 1;

        $offset = $paged * $per_page;

        $this->items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, $offset), ARRAY_A);

        $this->set_pagination_args(array(
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ));
    }

}

// Define Plugin Menu
function wpkdl_admin_menu()
{
    add_menu_page(__('KONDESK', 'wpkdl'), __('KONDESK', 'wpkdl'), 'activate_plugins', 'kdleads', 'wpkdl_kdleads_page_handler', 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDkiIHZpZXdCb3g9IjAgMCA0OCA0OSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTQ4LjAwMDEgMjQuOTk3OUM0Ny45OTY0IDMwLjAxMjcgNDYuNDI0NiAzNC45MDA1IDQzLjUwNDkgMzguOTc2MUM0MC41ODUzIDQzLjA1MTYgMzYuNDY0MyA0Ni4xMTAzIDMxLjcxOTkgNDcuNzIzNEMyNi45NzU1IDQ5LjMzNjQgMjEuODQ1NiA0OS40MjI5IDE3LjA0OTcgNDcuOTcwNkMxMi4yNTM3IDQ2LjUxODMgOC4wMzIxOCA0My42MDAxIDQuOTc3MTIgMzkuNjI1M0MxLjkyMjA1IDM1LjY1MDQgMC4xODY2NyAzMC44MTgzIDAuMDE0MzI4MSAyNS44MDY0Qy0wLjE1ODAxNCAyMC43OTQ2IDEuMjQxMzMgMTUuODU0NSA0LjAxNjEyIDExLjY3ODlDNi43OTA5MiA3LjUwMzIyIDEwLjgwMiA0LjMwMTQ3IDE1LjQ4NjggMi41MjI2M0MyMC4xNzE3IDAuNzQzNzg1IDI1LjI5NTQgMC40NzcwNTcgMzAuMTM5NCAxLjc1OTg1TDI0Ljc3NDcgNS43ODUzM0MyNC41MTE3IDUuNzc0NzEgMjQuMjQ5OCA1Ljc2ODM1IDIzLjk4NDcgNS43NjgzNUMxOS42NTAyIDUuNzY3NTMgMTUuNDQyOCA3LjIzMzM4IDEyLjA0NTkgOS45Mjc4MUM4LjY0ODk3IDEyLjYyMjIgNi4yNjIwNCAxNi4zODY5IDUuMjcyODMgMjAuNjEwNEM0LjI4MzYyIDI0LjgzMzkgNC43NTAyNCAyOS4yNjgxIDYuNTk2OSAzMy4xOTI2QzguNDQzNTYgMzcuMTE3MiAxMS41NjE4IDQwLjMwMTcgMTUuNDQ1IDQyLjIyODdDMTkuMzI4MyA0NC4xNTU4IDIzLjc0ODUgNDQuNzEyMiAyNy45ODc3IDQzLjgwNzdDMzIuMjI2OCA0Mi45MDMyIDM2LjAzNTkgNDAuNTkwOCAzOC43OTYyIDM3LjI0NjJDNDEuNTU2NSAzMy45MDE2IDQzLjEwNTggMjkuNzIxMiA0My4xOTI1IDI1LjM4NDFDNDMuMjc5MiAyMS4wNDcgNDEuODk4MyAxNi44MDggMzkuMjczOSAxMy4zNTU1VjYuNDU5MjVDNDIuMDA1OCA4LjcxMjg4IDQ0LjIwNTEgMTEuNTQ0IDQ1LjcxMzkgMTQuNzQ5NEM0Ny4yMjI2IDE3Ljk1NDcgNDguMDAzNCAyMS40NTQ3IDQ4LjAwMDEgMjQuOTk3OVoiIGZpbGw9IiNmZmZmZmYiLz4KPHBhdGggZD0iTTM3LjQ0MDEgMEwyNC4wMDAxIDkuNzk5NTdMMzcuNDQwMSAxNi4zMzMzVjBaIiBmaWxsPSIjZmZmZmZmIi8+Cjwvc3ZnPgo=');

    add_submenu_page('kdleads', __('Leads', 'wpkdl'), __('Leads', 'wpkdl'), 'activate_plugins', 'kdleads', 'wpkdl_kdleads_page_handler');

    add_submenu_page('kdleads', __('Add New Lead', 'wpkdl'), __('Add New Lead', 'wpkdl'), 'activate_plugins', 'kdleads_form', 'wpkdl_kdleads_form_page_handler');

    add_submenu_page('kdleads', __('Configure', 'wpkdl'), __('Configure', 'wpkdl'), 'activate_plugins', 'kdleads_settings', 'wpkdl_kdleads_settings_page_handler');
}

add_action('admin_menu', 'wpkdl_admin_menu');

add_action('wp_enqueue_scripts', 'my_plugin_assets');

function my_plugin_assets()
{

    wp_register_script('wpkdl-leads', plugins_url('/js/leads.js', __FILE__), array('jquery'), '1.0.0', true);

    wp_enqueue_script('wpkdl-leads');

    wp_localize_script(
        'wpkdl-leads',
        'wpkdl',
        array(

            'ajax_url'        =>  admin_url('admin-ajax.php')
        )
    );
}

function wpkdl_languages()
{
    load_plugin_textdomain('wpkdl', false, dirname(plugin_basename(__FILE__)));
}

add_action('init', 'wpkdl_languages');


// User Lead Form with Validation
add_shortcode('kondesk_lead', 'kondesk_lead');

function kondesk_lead() {
    $options = get_option('wpkdl_options');

    global $wpdb;
    $table_name = $wpdb->prefix . 'access_keys';

    // Retrieve the access key from the wp_access_keys table
    $access_key_token = $wpdb->get_var( "SELECT access_key FROM $table_name ORDER BY id DESC LIMIT 1" );

// Check if the user's access key token matches the valid access key token
if (!empty($access_key_token)) {
    // The access key token is valid, display the form

    $form = '<div class="Lead-Form">';
    $form .= '<form id="kondesk-register-ads-form" class="row g-3">';

        $fields = array(
            array(
                'name' => 'firstname',
                'label' => 'First Name'
            ),
            array(
                'name' => 'lastname',
                'label' => 'Last Name'
            ),
            array(
                'name' => 'email',
                'label' => 'Email'
            ),
            array(
                'name' => 'mobile',
                'label' => 'Mobile'
            ),
            // array(
            //     'name' => 'company',
            //     'label' => 'Company'
            // ),
            // array(
            //     'name' => 'web',
            //     'label' => 'Website'
            // ),
            array(
                'name' => 'job',
                'label' => 'Job Title'
            ),
            array(
                'name' => 'address',
                'label' => 'Address'
            ),
            array(
                'name' => 'message',
                'label' => 'Comments'
            )
            ,
            array(
                'name' => 'city',
                'label' => 'City'
            )
            ,
            array(
                'name' => 'state',
                'label' => 'State'
            )
            ,
            array(
                'name' => 'country',
                'label' => 'Country'
            )
            ,
            array(
                'name' => 'dateofbirth',
                'label' => 'Date of Birth'
            )
            ,
            array(
                'name' => 'nationality',
                'label' => 'Nationality'
            )
            ,
            array(
                'name' => 'gender',
                'label' => 'Gender'
            )
            ,
            array(
                'name' => 'maritalstatus',
                'label' => 'Marital Status'
            )
            ,
            array(
                'name' => 'inquirytype',
                'label' => 'Inquiry Type'
            )
            ,
            array(
                'name' => 'zipcode',
                'label' => 'Zipcode'
            )
        );

        $form .= '<script>';
        $form .= 'document.addEventListener("DOMContentLoaded", function() {';
        $form .= 'var fieldSettings = ' . json_encode($options) . ';';
        $form .= 'var fieldElements = document.querySelectorAll(".col-md-4");';
        $form .= 'Array.from(fieldElements).forEach(function(element) {';
        $form .= 'var fieldName = element.querySelector("input").getAttribute("name");';
        $form .= 'var isFieldHidden = fieldSettings[fieldName] === "" || fieldSettings[fieldName] === undefined;';
        $form .= 'element.style.display = isFieldHidden ? "none" : "block";';
        $form .= 'if (isFieldHidden) {';
        $form .= 'element.parentNode.removeChild(element);'; // Remove the element from the DOM
        $form .= '}';
        $form .= '});';
        $form .= '});';
        $form .= '</script>';

        foreach ($fields as $field) {
            //wpkdl_field_settings($field);

            $field_name = $field['name'];
            $field_label = $field['label'];
            $field_value = !empty($options[$field_name]) ? $options[$field_name] : '';
            $field_required = isset($options['required_fields']) && in_array($field_name, $options['required_fields']);

            $form .= '<div class="col-md-4 col-12">';
            $form .= '<div class="form-group">';
            $form .= '<label class="form-check-label w-100 mb-2" for="' . esc_attr($field_name) . '">' . esc_html__($field_label) . '</label>';
            $form .= '<input class="form-control" id="' . esc_attr($field_name) . '" name="' . esc_attr($field_name) . '" type="text" value="" ' . ($field_required ? 'required' : '') . '>';
            $form .= '</div>';
            $form .= '</div>';
        }

        $form .= '<div class="col-md-12 col-12 text-center mt-4">';
            $form .= '<div class="form-group">';
            
            $form .= '<button class="btn btn-success px-md-4" type="button" onclick="KondeskRequestADemo()" id="kondesk-submit">Submit</button>';
            $form .= '</div>';
        $form .= '</div>';

        $form .= '<div id="OutputMsg" class="alert alert-dismissible alert-success col-12 col-md-6 mx-auto font-weight-normal mt-4 p-2 success-msg text-center"> </div>';
   

    $form .= '</form>';
    $form .= '<input class="form-control" id="access_key_token" type="hidden" name="access_key_token" value="' . esc_attr( $access_key_token ) . '">';
    $form .= '</div>';

    $form .= '<script src="https://konze.com/wp-content/themes/konze/assets/js/jquery.validate.min.js?ver=1.0.0"></script>';
        
    return $form;
    // Print the access key token value here
    echo 'Access Key Token Value: ' . $access_key_token;
    } else {
        // The access key token is invalid or not provided, display an error message or deny access
        return '<div class="alert alert-danger kondesk-error-msg">Access denied. Please provide a valid <b>API Key</b> token.</div>';
    }
}

// Send Form data in to API
function wpkdl_get_leads()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'access_keys';

    // Retrieve the access key from the wp_access_keys table
    $access_key_token = $wpdb->get_var( "SELECT access_key FROM $table_name ORDER BY id DESC LIMIT 1" );
    
    $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
    $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $mobileno = isset($_POST['mobile']) ? $_POST['mobile'] : '';
    // $companyname = isset($_POST['companyname']) ? $_POST['companyname'] : '';
    // $web = isset($_POST['web']) ? $_POST['web'] : '';
    $job = isset($_POST['job']) ? $_POST['job'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $message = isset($_POST['message']) ? $_POST['message'] : '';
    $city = isset($_POST['city']) ? $_POST['city'] : '';
    $state = isset($_POST['state']) ? $_POST['state'] : '';
    $country = isset($_POST['country']) ? $_POST['country'] : '';
    $dateofbirth = isset($_POST['dateofbirth']) ? $_POST['dateofbirth'] : '';
    $nationality = isset($_POST['nationality']) ? $_POST['nationality'] : '';
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $maritalstatus = isset($_POST['maritalstatus']) ? $_POST['maritalstatus'] : '';
    $inquirytype = isset($_POST['inquirytype']) ? $_POST['inquirytype'] : '';
    $zipcode = isset($_POST['zipcode']) ? $_POST['zipcode'] : '';


    // Set the request headers
    $headers = array(
        'Content-Type'  => 'application/json',
        'Authorization' => 'Bearer ' . $access_key_token,
    );

    // Prepare the data to be sent in the request
    $register_field_data = array(
        'firstname' => $firstname,
        'lastname' => $lastname,
        'email' => $email,
        'mobile' => $mobileno,
        // 'company' => $companyname,
        // 'web' => $web,
        'job' => $job,
        'address' => $address,
        'message' => $message,
        'city' => $city,
        'state' => $state,
        'country' => $country,
        'dateofbirth' => $dateofbirth,
        'nationality' => $nationality,
        'gender' => $gender,
        'maritalstatus' => $maritalstatus,
        'inquirytype' => $inquirytype,
        'zipcode' => $zipcode,
    );

    $access_key_token = $wpdb->get_var( "SELECT access_key FROM $table_name ORDER BY id DESC LIMIT 1" );
    $url = 'https://stagingwebhook.kondesk.com/wordpress?key=' . urlencode($access_key_token);

    // Log the URL
    error_log("API URL: $url");

    $ch1 = curl_init($url);
    curl_setopt($ch1, CURLOPT_POST, 1);
    curl_setopt($ch1, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch1, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
    curl_setopt($ch1, CURLOPT_POSTFIELDS, json_encode($register_field_data));

    $response = curl_exec($ch1);

    curl_close($ch1);

    // Decode the JSON response into an associative array
    $result = json_decode($response, true);

    // Check if the response was successful
    if ($result['flag'] === true) {
        $message = $result['message'];

        global $wpdb;
        
        $table_name = $wpdb->prefix . 'kd_leads';

        // Insert the data into the table
        $result = $wpdb->insert($table_name, $register_field_data);

        if ($result === false) {
            // Failed to insert data into the database
            $message = "Error: " . $wpdb->last_error;
        } else {
            // Data inserted successfully
            $message = "Success: " . $message;

            // Return a JSON response with the success message
            wp_send_json_success($message);
        }
    } else {
        $message = "Error: " . $result['message'];
    }

    echo $message;

}
add_action('wp_ajax_wpkdl_get_leads', 'wpkdl_get_leads');
add_action('wp_ajax_nopriv_wpkdl_get_leads', 'wpkdl_get_leads');


// Validation Function
function wpkdl_validate_kdlead($item)
{
    $options = get_option('wpkdl_options');
    $messages = array();

    // Check if the required_fields option is set and is an array
    if (!empty($options) && isset($options['required_fields']) && is_array($options['required_fields'])) {
        $required_fields = $options['required_fields'];

        // Iterate through each field and validate if it is required
        foreach ($required_fields as $field_name) {
            // Check if the field exists in the form data
            if (isset($item[$field_name])) {
                // Additional validation for specific fields if needed
                switch ($field_name) {
                    case 'firstname':
                        if (!empty($options['firstname']) && isset($options['firstname']) && empty($item['firstname'])) {
                            $messages[] = __('First Name is required', 'wpkdl');
                        }
                        break;
                    case 'lastname':
                        if (!empty($options['lastname']) && isset($options['lastname']) && empty($item['lastname'])) {
                            $messages[] = __('Last Name is required', 'wpkdl');
                        }
                        break;
                    case 'email':
                        if (!empty($options['emailid']) && isset($options['email']) && empty($item['email'])) {
                            $messages[] = __('Email is required', 'wpkdl');
                        } elseif (!filter_var($item['email'], FILTER_VALIDATE_EMAIL)) {
                            $messages[] = __('Invalid email format', 'wpkdl');
                        }
                        break;
                    case 'mobile':
                        if (!empty($options['mobile']) && isset($options['mobile']) && empty($item['mobile'])) {
                            $messages[] = __('Mobile is required', 'wpkdl');
                        }elseif (!preg_match('/^\d{1,12}$/', $item['mobile'])) {
                            $messages[] = __('Invalid mobile number format', 'wpkdl');
                        }
                        break;
                    // case 'company':
                    //     if (!empty($options['company']) && isset($options['company']) && empty($item['company'])) {
                    //         $messages[] = __('Company is required', 'wpkdl');
                    //     }
                    //     break;
                    // case 'web':
                    //     if (!empty($options['web']) && isset($options['web']) && empty($item['web'])) {
                    //         $messages[] = __('Web is required', 'wpkdl');
                    //     }elseif (!preg_match('/^(https?:\/\/)/', $item['web'])) {
                    //         $messages[] = __('Website should start with "http://" or "https://"', 'wpkdl');
                    //     }
                    //     break;
                    case 'job':
                        if (!empty($options['job']) && isset($options['job']) && empty($item['job'])) {
                            $messages[] = __('Job Title is required', 'wpkdl');
                        }
                        break;
                    case 'address':
                        if (!empty($options['address']) && isset($options['address']) && empty($item['address'])) {
                            $messages[] = __('Address is required', 'wpkdl');
                        }
                        break;
                    case 'notes':
                        if (!empty($options['message']) && isset($options['message']) && empty($item['message'])) {
                            $messages[] = __('Notes is required', 'wpkdl');
                        }
                        break;
                    case 'city':
                        if (!empty($options['city']) && isset($options['city']) && empty($item['city'])) {
                            $messages[] = __('City is required', 'wpkdl');
                        }
                        break;
                    case 'state':
                        if (!empty($options['state']) && isset($options['state']) && empty($item['state'])) {
                            $messages[] = __('State is required', 'wpkdl');
                        }
                        break;
                    case 'country':
                        if (!empty($options['country']) && isset($options['country']) && empty($item['country'])) {
                            $messages[] = __('Country is required', 'wpkdl');
                        }
                        break;
                        case 'dateofbirth':
                            if (!empty($options['dateofbirth']) && isset($options['dateofbirth']) && empty($item['dateofbirth'])) 
                            {
                                $messages[] = __('Date of Birth is required', 'wpkdl');
                            }elseif (!preg_match('/^\d{2}-\d{2}-\d{4}$/', $item['dateofbirth'])) {
                                $messages[] = __('Invalid Date of Birth format', 'wpkdl');
                            }
                            break;
                        case 'nationality':
                            if (!empty($options['nationality']) && isset($options['nationality']) && empty($item['nationality'])) {
                                $messages[] = __('nationality is required', 'wpkdl');
                            }
                            break;
                        case 'gender':
                            if (!empty($options['gender']) && isset($options['gender']) && empty($item['gender'])) {
                                $messages[] = __('gender is required', 'wpkdl');
                            }
                            break;
                        case 'maritalstatus':
                            if (!empty($options['maritalstatus']) && isset($options['maritalstatus']) && empty($item['maritalstatus'])) {
                                $messages[] = __('Marital status is required', 'wpkdl');
                            }
                            break;
                        case 'inquirytype':
                            if (!empty($options['inquirytype']) && isset($options['inquirytype']) && empty($item['inquirytype'])) {
                                $messages[] = __('Inquiry type is required', 'wpkdl');
                            }
                            break;
                        case 'zipcode':
                            if (!empty($options['zipcode']) && isset($options['zipcode']) && empty($item['zipcode'])) {
                                $messages[] = __('Zipcode is required', 'wpkdl');
                            }
                            break;    
                    // Add more cases for other fields if needed
                }
            }
        }
    }

    if (empty($messages)) {
        return true;
    } else {
        return implode('<br>', $messages);
    }
}