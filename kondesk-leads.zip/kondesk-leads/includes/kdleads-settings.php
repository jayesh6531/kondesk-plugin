<?php
/**
 * @internal never define functions inside callbacks.
 * these functions could be run multiple times; this would result in a fatal error.
 */

/**
 * custom option and settings
 */
function wpkdl_settings_init() {
    // Register a new setting for the "wpkdl" page.
    register_setting( 'wpkdl', 'wpkdl_options' );

    // Register a new section in the "wpkdl" page.
    add_settings_section(
        'wpkdl_section_developers',
        __( '', 'wpkdl' ),
        'wpkdl_section_developers_callback',
        'wpkdl'
    );

    $fields = array(
        "firstname"      => "First Name",
        "lastname"       => "Last Name",
        "email"          => "Email Address",
        "mobile"          => "Mobile Number",
        // "company"        => "Company",
        // "web"            => "Website",
        "job"            => "Job Title",
        "address"        => "Address",
        "message"        => "Notes",
        'city'           => 'City',
        'state'          => 'State',
        'country'        => 'Country',
        "dateofbirth"    => "Date of Birth",
        "nationality"    => "Nationality",
        "gender"         => "Gender",
        'maritalstatus'  => 'Marital Status',
        'inquirytype'    => 'Inquiry Type',
        'zipcode'        => 'Zipcode'
    );

    $columns = 3; // Number of columns

    $field_chunks = array_chunk($fields, ceil(count($fields) / $columns), true);

   // echo '<table class="wpkdl-fields-table">';
   // echo '<tr><th>Field Name</th><th>Is Visible</th><th>Is Required</th></tr>';

    foreach ($field_chunks as $column) {
        foreach ($column as $field_name => $field_label) {
            add_settings_field(
                'wpkdl_field_' . $field_name . '_settings',
                __( $field_label, 'wpkdl' ),
                'wpkdl_field_settings',
                'wpkdl',
                'wpkdl_section_developers',
                array(
                    'name'              => $field_name,
                    'label'             => $field_label,
                    'class'             => 'wpkdl_row hide',
                    'wpkdl_custom_data' => 'custom',
                )
            );
        }
    }

   // echo '</table>';
}


function wpkdl_field_settings( $args ) {
    $options = get_option( 'wpkdl_options' );

    // Get the field name and label from the $args array
    $field_name = $args['name'];
    $field_label = $args['label'];
    $field_value = ! empty( $options[ $field_name ] ) ? $options[ $field_name ] : '';
    $field_required = isset( $options['required_fields'] ) && in_array( $field_name, $options['required_fields'] );

    // Output the field settings HTML
    echo '<tr class="bg-white">';
    echo '<td width="30%" style="font-weight: 400;">' . esc_html__( $field_label ) . '</td>';
    echo '<td width="30%"><input id="wpkdl_' . esc_attr( $field_name ) . '_field_settings" name="wpkdl_options[' . esc_attr( $field_name ) . ']" type="checkbox" value="' . esc_attr( $field_name ) . '" ' . checked( $field_value, $field_name, false ) . '></td>';
    echo '<td><input id="wpkdl_' . esc_attr( $field_name ) . '_field_required" name="wpkdl_options[required_fields][]" type="checkbox" value="' . esc_attr( $field_name ) . '" ' . checked( $field_required, true, false ) . '></td>';
    echo '</tr>';
}
// Function to reset the options to their default values
function wpkdl_reset_options() {
    $default_options = array();
    global $fields;

    foreach ($fields as $field_name => $field_label) {
        $default_options[$field_name] = ''; // Set all fields to empty values
    }

    update_option('wpkdl_options', $default_options);
}

/**
 * Register our wpkdl_settings_init to the admin_init action hook.
 */
add_action( 'admin_init', 'wpkdl_settings_init' );


/**
 * Custom option and settings:
 *  - callback functions
 */


/**
 * Developers section callback function.
 *
 * @param array $args  The settings array, defining title, id, callback.
 */
function wpkdl_section_developers_callback( $args ) {
    $options = get_option( 'wpkdl_options' );
    ?>
    <h6 id="<?php echo esc_attr( $args['id'] ); ?>" class="alert alert-warning p-2">
        <?php esc_html_e( 'To make a field visible, you can check the corresponding "Is Visible" checkbox. Similarly, to indicate that a field is required, you can check the "Is Required" checkbox.', 'wpkdl' ); ?>
    </h6>  
    
    <?php
        $options = get_option( 'wpkdl_options' );

        // Retrieve the saved access key from the wp_access_keys table
        global $wpdb;
        $table_name = $wpdb->prefix . 'access_keys';
        $access_key_token = $wpdb->get_var( "SELECT access_key FROM $table_name ORDER BY id DESC LIMIT 1" );
    
        // Output the HTML for the access key section
    ?>

    <div class="row g-2 align-items-center justify-content-start mb-4 mx-0">
        <div class="col-12">
           <div class="alert alert-info p-2">To Show kondesk Lead Form in your Pages / Posts, Copy and paste this shortcode : 
             <span class="fw-bold">[kondesk_lead]</span>
           </div>
        </div>
        <div class="col">
            <div class="row g-2 align-items-center mx-0">
                <label class="col-auto form-check-label pr-0 fw-bold" for="wpkdl_access_key_token">API Key</label>
                <div class="col-md-3">
                    <input type="text" class="form-control" id="wpkdl_access_key_token" name="wpkdl_options[access_key_token]" value="<?php echo esc_attr( $access_key_token ); ?>">
                </div>
                <div class="col-auto pl-0">
                    <button id="save_settings_button" class="btn btn-secondary p-1 px-3" type="submit">Save key</button>
                </div>
                <div id="OutputMsg" class="col-auto text-muted"></div>
            </div>
        </div>
        <div class="col-auto alert alert-primary font-italic mb-0 p-1 px-2" id="current_access_key_section">
            <span for="current_access_key">Current API Key :</span>
            <span id="current_access_key" class="fw-bold" value="<?php echo esc_attr($access_key_token); ?>"><?php echo esc_attr($access_key_token); ?></span>
            <button id="delete_access_key_button" class="btn btn-danger ms-2 p-0 px-2 small">Delete</button>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Show/Hide the "Current Access Key" section initially based on the key presence
        var accessKeyToken = $('#current_access_key').text();
        if (accessKeyToken !== '') {
            $('#current_access_key_section').show();
            // Clear the textbox
            $('#wpkdl_access_key_token').val('');
        } else {
            $('#current_access_key_section').hide();
        }

        // Handle Save Settings button click
        $('#save_settings_button').on('click', function(event) {
            event.preventDefault(); // Prevent form submission

            var accessKeyToken = $('#wpkdl_access_key_token').val();

            if (accessKeyToken !== '') {
                // Save the access key via AJAX
                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'wpkdl_save_access_key',
                        accessKeyToken: accessKeyToken,
                    },
                    success: function(response) {
                        // Handle success response
                        console.log('Access key saved successfully!');
                        $('#OutputMsg').show().html('Key Saved Successfully!');

                        // Hide the message after 3 seconds
                        setTimeout(function() {
                            $('#OutputMsg').hide();
                        }, 3000);

                        // Clear the textbox
                        $('#wpkdl_access_key_token').val('');

                        // Show/Hide the "Current Access Key" section
                        if (accessKeyToken !== '') {
                            $('#current_access_key_section').show();
                            $('#current_access_key').text(accessKeyToken);
                        } else {
                            $('#current_access_key_section').hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle error response
                        console.log('Error saving access key: ' + error);
                    }
                });
            }
        });

        // Handle Delete Access Key button click
        $('#delete_access_key_button').on('click', function(event) {
            event.preventDefault(); // Prevent form submission

            // Delete the access key via AJAX
            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                data: {
                    action: 'wpkdl_delete_access_key',
                },
                success: function(response) {
                    // Handle success response
                    console.log('Access key deleted successfully!');
                    $('#OutputMsg').show().html('Access key deleted successfully!');
                    // Hide the message after 3 seconds
                    setTimeout(function() {
                        $('#OutputMsg').hide();
                    }, 3000);
                    $('#current_access_key_section').hide();
                },
                error: function(xhr, status, error) {
                    // Handle error response
                    console.log('Error deleting access key: ' + error);
                }
            });
        });
    });
</script>

    <?php
}

// Delete the access key from the database
function wpkdl_delete_access_key() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'access_keys';

    $wpdb->query("TRUNCATE TABLE $table_name");

    // Return a response (success/error) if needed
    wp_die();
}
add_action('wp_ajax_wpkdl_delete_access_key', 'wpkdl_delete_access_key');
add_action('wp_ajax_nopriv_wpkdl_delete_access_key', 'wpkdl_delete_access_key');


// Create the access keys table
function wpkdl_create_access_keys_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'access_keys';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT AUTO_INCREMENT,
        access_key VARCHAR(255),
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'wpkdl_create_access_keys_table');

// Save the access key to the database
function wpkdl_save_access_key() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'access_keys';

    // Create the access keys table if it doesn't exist
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT AUTO_INCREMENT,
        access_key VARCHAR(255),
        PRIMARY KEY (id)
    ) $charset_collate;";
    $wpdb->query($sql);

    $access_key_token = isset($_POST['accessKeyToken']) ? sanitize_text_field($_POST['accessKeyToken']) : '';

    // Save the access key to the database
    $wpdb->insert($table_name, array('access_key' => $access_key_token));

    // Return a response (success/error) if needed
    wp_die();
}
add_action('wp_ajax_wpkdl_save_access_key', 'wpkdl_save_access_key');
add_action('wp_ajax_nopriv_wpkdl_save_access_key', 'wpkdl_save_access_key');




// AJAX callback function to save settings
function wpkdl_save_settings_callback() {
    // Verify the AJAX request and user capabilities
    check_ajax_referer( 'wpkdl_ajax_nonce', 'security' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized' );
    }

    // Get the options from the AJAX request
    $options = $_POST['options'];

    // Update the 'access_key_token' value in the options
    update_option( 'wpkdl_options', $options );

    // Return success response
    wp_send_json_success( 'Settings saved successfully' );
}
add_action( 'wp_ajax_wpkdl_save_settings', 'wpkdl_save_settings_callback' );
add_action( 'wp_ajax_nopriv_wpkdl_save_settings', 'wpkdl_save_settings_callback' );

function wpkdl_name_field_settings( $args ) {
	// Get the value of the setting we've registered with register_setting()
	$options = get_option( 'wpkdl_options' );
	?>
<select id="<?php echo esc_attr( $args['label_for'] ); ?>"
    data-custom="<?php echo esc_attr( $args['wpkdl_custom_data'] ); ?>"
    name="wpkdl_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
    <option value="red"
        <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], 'red', false ) ) : ( '' ); ?>>
        <?php esc_html_e( 'red pill', 'wpkdl' ); ?>
    </option>
    <option value="blue"
        <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], 'blue', false ) ) : ( '' ); ?>>
        <?php esc_html_e( 'blue pill', 'wpkdl' ); ?>
    </option>
</select>

<?php
}


/**
 * Top level menu callback function
 */
function wpkdl_kdleads_settings_page_handler() {
	// check user capabilities
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// add error/update messages

	// check if the user have submitted the settings
	// WordPress will add the "settings-updated" $_GET parameter to the url
	if ( isset( $_GET['settings-updated'] ) ) {
		// add settings saved message with the class of "updated"
		add_settings_error( 'wpkdl_messages', 'wpkdl_message', __( 'Settings Saved', 'wpkdl' ), 'updated' );
	}

	// show error/update messages
	settings_errors( 'wpkdl_messages' );
	?>
    <div class="wpkdl-settings-page">
        <h4 style="display: flex; font-size: 22px; width: 90%; align-items: center; border-bottom: 1px solid #dddddd; padding: 0px 0px 10px; margin: 0px 0px 15px;">
            <img src="https://konze.com/wp-content/themes/konze/assets/images/icon04.svg" width="34" style="margin: 0 10px 0px 0px;" />
            <?php echo esc_html( get_admin_page_title() ); ?> 
            Page settings
        </h4>
        <form action="options.php" method="post">
            <?php
            // Output security fields for the registered setting "wpkdl"
            settings_fields( 'wpkdl' );

            // Output setting sections and their fields
            //do_settings_sections( 'wpkdl' );
            ?>
            <div class="wpkdl-field-group">
                <table class="wpkdl-field-settings bg-white">
                    <thead>
                        <tr>
                            <th width="30%"><?php esc_html_e( 'Field Name', 'wpkdl' ); ?></th>
                            <th width="30%"><?php esc_html_e( 'Is Visible', 'wpkdl' ); ?></th>
                            <th><?php esc_html_e( 'Is Required', 'wpkdl' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php do_settings_sections( 'wpkdl' ); ?>
                    </tbody>
                </table>
            </div>
            <div class="row g-3 justify-content-end">
                <div class="col-12 text-end wpkdl-submit-button">
                    <?php submit_button( 'Save Settings' ); ?>
                </div>
            </div>        
        </form>
    </div>
<?php
}