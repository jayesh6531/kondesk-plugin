<?php
// Lead List
function wpkdl_kdleads_page_handler()
{
    global $wpdb;

    $table = new Custom_Table_Example_List_Table();
    $table->prepare_items();

    $message = '';
    if ('delete' === $table->current_action() && isset($_REQUEST['id']) && is_array($_REQUEST['id'])) {
        $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted: %d', 'wpkdl'), count($_REQUEST['id'])) . '</p></div>';
    }
    ?>
    <div class="wrap">

        <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
        <h4 style="display: flex; font-size: 22px; width: 100%; justify-content: space-between; 
        align-items: center; border-bottom: 1px solid #dddddd; padding: 0px 0px 10px; margin: 0px 0px 15px;">

            <span style="display: flex; align-items: center;">
                <img src="https://konze.com/wp-content/themes/konze/assets/images/icon04.svg" width="34" style="margin: 0 10px 0px 0px;" />
                <?php _e('KONDESK Leads', 'wpkdl') ?>
            </span>

            <a class="add-new-h2" style="font-size: 15px; margin: 15px 0px 0px;" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=kdleads_form'); ?>"><?php _e('Add New Lead', 'wpkdl') ?>
            </a>
        </h4>

        <h2 class="d-none" style="display: none;">
            <?php _e('KONDESK Leads', 'wpkdl')?> 
            <a class="add-new-h2"
                href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=kdleads_form');?>">
                <?php _e('Add New Lead', 'wpkdl')?>
            </a>
        </h2>
        <?php echo $message; ?>

        <form id="contacts-table" method="POST">
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
            <?php $table->display() ?>
        </form>

    </div>
    <?php
}

//Add New Lead
function wpkdl_kdleads_form_page_handler()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'kd_leads'; 

    $message = '';
    $notice = '';


    $default = array(
        'id' => 0,
        'firstname'      => '',
        'lastname'  => '',
        'email'     => '',
        'mobile'     => null,
        // 'company'   => '',
        // 'web'       => '',  
        'job'       => '',        
        'address'   => '',
        'message'   => '',
        'city'      => '',
        'state'     => '',
        'country'   => '',
        'dateofbirth'    => '',        
        'nationality'    => '',
        'gender'         => '',
        'maritalstatus'  => '',
        'inquirytype'    => '',
        'zipcode'        => ''
    );


    if ( isset($_REQUEST['nonce']) && wp_verify_nonce($_REQUEST['nonce'], basename(__FILE__))) {
        
        $item = shortcode_atts($default, $_REQUEST);     

        $item_valid = wpkdl_validate_kdlead($item);

        if ($item_valid === true) {
            if ($item['id'] == 0) {
                $result = $wpdb->insert($table_name, $item);
                $item['id'] = $wpdb->insert_id;
                if ($result) {
                    $message = __('Item was successfully saved', 'wpkdl');
                } else {
                    $notice = __('There was an error while saving item', 'wpkdl');
                }
            } else {
                $result = $wpdb->update($table_name, $item, array('id' => $item['id']));
                if ($result) {
                    $message = __('Item was successfully updated', 'wpkdl');
                } else {
                    $notice = __('There was an error while updating item', 'wpkdl');
                }
            }
        } else {
            
            $notice = $item_valid;
        }
    }
    else {
        
        $item = $default;
        if (isset($_REQUEST['id'])) {
            $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $_REQUEST['id']), ARRAY_A);
            if (!$item) {
                $item = $default;
                $notice = __('Item not found', 'wpkdl');
            }
        }
    }
    
    add_meta_box('kdleads_form_meta_box', __('KONDESK Leads Data', 'wpkdl'), 'wpkdl_kdleads_form_meta_box_handler', 'kdlead', 'normal', 'default');

    ?>
    <div class="wrap">
        <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>

        <h4 style="display: flex; font-size: 22px; width: 100%; justify-content: space-between;border-bottom: 1px solid #dddddd; padding: 0px 0px 10px; margin: 0px 0px 15px;">

                <span style="display: flex; align-items: center;">
                    <img src="https://konze.com/wp-content/themes/konze/assets/images/icon04.svg" width="34" style="margin: 0 10px 0px 0px;">
                    <?php _e('Add New Lead', 'wpkdl') ?>
                </span>

                <a class="add-new-h2" style="font-size: 15px; margin: 15px 0px 0px;" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=kdleads'); ?>"><?php _e('Back to Leads', 'wpkdl') ?>
                </a>
        </h4>

        <h2 class="d-none" style="display: none;">
            <?php _e('KONDESK Leads', 'wpkdl')?> 
            <a class="add-new-h2"
                href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=kdleads');?>">
                <?php _e('Back to Leads', 'wpkdl')?>
            </a>
        </h2>

        <div class="row">
                <div class="col-12 text-end">
                    <?php if (!empty($notice)) : ?>
                        <div id="notice" class="error">
                            <p class="d-flex"><?php echo $notice ?></p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-12 text-end">
                    <?php if (!empty($message)) : ?>
                        <div id="message" class="updated">
                            <p><?php echo $message ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <form id="form" method="POST">
            <input type="hidden" name="nonce" value="<?php echo wp_create_nonce(basename(__FILE__))?>" />

            <input type="hidden" name="id" value="<?php echo $item['id'] ?>" />

            <div class="metabox-holder" id="poststuff">
                <div id="post-body">
                    <div id="post-body-content">
                        <?php do_meta_boxes('kdlead', 'normal', $item); ?>
                        <div class="row g-3">
                                <div class="col-12 text-end">
                                    <input type="submit" value="<?php _e('Save', 'wpkdl') ?>" id="submit" class="button-primary" name="submit">
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <?php
}

//Add New Lead Form Controls
function wpkdl_kdleads_form_meta_box_handler($item)
{
    $options = get_option( 'wpkdl_options' );
    ?>
   <tbody>
        <div class="row g-4 p-2">
            <form class="row g-4">
                <?php if (!empty($options) && isset($options['firstname'])) { ?>
                    <div class="col-md-4 col-12">                   
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="firstname"><?php _e('First Name:', 'wpkdl') ?></label>
                            <input class="form-control" id="firstname" name="firstname" type="text" value="<?php echo esc_attr($item['firstname']) ?>">
                        </div>                   
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['lastname'])) { ?>
                    <div class="col-md-4 col-12">                   
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="lastname"><?php _e('Last Name:', 'wpkdl') ?></label>
                            <input class="form-control" id="lastname" name="lastname" type="text" value="<?php echo esc_attr($item['lastname']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['email'])) { ?>
                    <div class="col-md-4 col-12">
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="email"><?php _e('E-Mail:', 'wpkdl') ?></label>
                            <input class="form-control" id="email" name="email" type="email" value="<?php echo esc_attr($item['email']) ?>">
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($options) && isset($options['mobile'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="mobile"><?php _e('Mobile:', 'wpkdl') ?></label>
                            <input class="form-control" id="mobile" name="mobile" type="tel" value="<?php echo esc_attr($item['mobile']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <!-- <?php if (!empty($options) && isset($options['company'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="company"><?php _e('Company:', 'wpkdl') ?></label>
                            <input class="form-control" id="company" name="company" type="text" value="<?php echo esc_attr($item['company']) ?>">
                        </div>                   
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['web'])) { ?>
                    <div class="col-md-4 col-12">                   
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="web"><?php _e('Web:', 'wpkdl') ?></label>
                            <input id="web" class="form-control" name="web" type="text" value="<?php echo esc_attr($item['web']) ?>">
                        </div>                    
                    </div>
                <?php } ?> -->

                <?php if (!empty($options) && isset($options['job'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="job"><?php _e('Job Title:', 'wpkdl') ?></label>
                            <input class="form-control" id="job" name="job" type="text" value="<?php echo esc_attr($item['job']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['city'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="city"><?php _e('City:', 'wpkdl') ?></label>
                            <input class="form-control" id="city" name="city" type="text" value="<?php echo esc_attr($item['city']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['state'])) { ?>
                    <div class="col-md-4 col-12">
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="state"><?php _e('State:', 'wpkdl') ?></label>
                            <input class="form-control" id="state" name="state" type="text" value="<?php echo esc_attr($item['state']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['country'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="country"><?php _e('Country:', 'wpkdl') ?></label>
                            <input class="form-control" id="country" name="country" type="text" value="<?php echo esc_attr($item['country']) ?>">
                        </div>                   
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['address'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="address"><?php _e('Address:', 'wpkdl') ?></label>
                            <input class="form-control" id="address" name="address" type="text" maxlength="240" value="<?php echo esc_attr($item['address']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['message'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="message"><?php _e('Notes:', 'wpkdl') ?></label>
                            <input class="form-control" id="message" name="message" type="text" maxlength="240" value="<?php echo esc_attr($item['message']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['dateofbirth'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="dateofbirth"><?php _e('Date of Birth:', 'wpkdl') ?></label>
                            <input class="form-control" id="dateofbirth" name="dateofbirth" type="text" value="<?php echo esc_attr($item['dateofbirth']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['nationality'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="nationality"><?php _e('Nationality:', 'wpkdl') ?></label>
                            <input class="form-control" id="nationality" name="nationality" type="text" value="<?php echo esc_attr($item['nationality']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['gender'])) { ?>
                    <div class="col-md-4 col-12">
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="gender"><?php _e('Gender:', 'wpkdl') ?></label>
                            <input class="form-control" id="gender" name="gender" type="text" value="<?php echo esc_attr($item['gender']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['maritalstatus'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="maritalstatus"><?php _e('Marital Status:', 'wpkdl') ?></label>
                            <input class="form-control" id="maritalstatus" name="maritalstatus" type="text" value="<?php echo esc_attr($item['maritalstatus']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['inquirytype'])) { ?>
                    <div class="col-md-4 col-12">                    
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="inquirytype"><?php _e('Inquiry Type:', 'wpkdl') ?></label>
                            <input class="form-control" id="inquirytype" name="inquirytype" type="text" value="<?php echo esc_attr($item['inquirytype']) ?>">
                        </div>                    
                    </div>
                <?php } ?>

                <?php if (!empty($options) && isset($options['zipcode'])) { ?>
                    <div class="col-md-4 col-12">
                        <div class="form-group">
                            <label class="form-check-label w-100 mb-2" for="zipcode"><?php _e('Zipcode:', 'wpkdl') ?></label>
                            <input class="form-control" id="zipcode" name="zipcode" type="text" value="<?php echo esc_attr($item['zipcode']) ?>">
                        </div>                    
                    </div>
                <?php } ?>
            </form>
        </div>
    </tbody>
    <?php
}
